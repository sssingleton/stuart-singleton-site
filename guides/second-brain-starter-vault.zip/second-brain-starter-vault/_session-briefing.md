# Session Briefing

> Read this first, every session. Keep it under one screen.

## Me in 30 seconds
- Name:
- What I do:
- Where I'm based / time zone:
- How I like to work with AI: (example: direct and concise, act then flag gaps, ask only when a wrong guess is expensive)

## Top rules (full list in [[Constraints/rules]])
1.
2.
3.

## Top 3 projects right now (full list in [[Projects/_active-projects]])
1.
2.
3.

## Open threads worth knowing (full list in [[Threads/_open-threads]])
-

## Tools and accounts connected (details in Stack/)
-
