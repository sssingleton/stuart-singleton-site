# Vault Map

> What lives where. Read this instead of scanning folders.

| Folder | Holds | Index |
|---|---|---|
| Profile/ | Who I am, how I work | Profile/about.md |
| Stack/ | Tools, accounts, integrations, tech choices | Stack/tools-and-integrations.md |
| Projects/ | Active work, one note per project | Projects/_active-projects.md |
| Threads/ | Running topics not settled yet | Threads/_open-threads.md |
| Decisions/ | Numbered decisions with reasons | Decisions/_decision-log.md |
| Constraints/ | Rules the AI follows every session | Constraints/rules.md |
| Glossary/ | My shorthand and acronyms | Glossary/terms.md |
| Templates/ | project.md, thread.md, decision.md | |
