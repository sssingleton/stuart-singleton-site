# Active Projects

> One line per project: link, status, next step. Update whenever a project starts, ships, or changes status.

## Current focus
- [[Projects/example-project]] · STATUS: `planning` · Next: replace this example with a real project.

## Active but not primary

## On hold

## Shipped
