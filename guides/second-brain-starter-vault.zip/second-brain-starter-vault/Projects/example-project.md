# Example Project

**Status**: `planning`
**Started**: YYYY-MM-DD
**Goal**: Replace this note with a real project, using Templates/project.md.

## What This Is
Two or three sentences.

## Key Decisions
- [[Decisions/001-example-decision]]

## Current State
What's done, what's next, any blockers.

## Open Questions
- 
