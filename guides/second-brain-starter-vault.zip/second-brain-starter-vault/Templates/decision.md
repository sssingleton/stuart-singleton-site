# Decision {{NNN}}: {{Short Title}}

**Date**: {{date}}
**Status**: `proposed` | `accepted` | `superseded`

## Context
What prompted this decision.

## Decision
What was decided.

## Alternatives Considered
- Alternative 1, and why not
- Alternative 2, and why not

## Consequences
- What this means going forward
