# {{Thread Title}}

**Status**: `active` | `resolved`
**Started**: {{date}}

## Context
Why this thread exists: what question or topic keeps coming up.

## Current Thinking
Latest state of understanding or approach.

## Updates
- **{{date}}**: what happened or changed
