# {{Project Name}}

**Status**: `planning` | `in-progress` | `blocked` | `on-hold` | `shipped`
**Started**: {{date}}
**Goal**: {{one-line goal}}

## What This Is
Two or three sentences.

## Key Decisions
- [[Decisions/NNN-decision-name]]

## Current State
What's done, what's next, any blockers.

## Open Questions
- 
