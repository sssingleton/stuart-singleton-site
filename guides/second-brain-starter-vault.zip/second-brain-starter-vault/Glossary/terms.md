# Glossary

> My shorthand, acronyms and nicknames, so the AI doesn't have to guess.

| Term | Means |
|---|---|
| | |
