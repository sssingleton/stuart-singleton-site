# Rules for the AI

> Standing instructions for every session. Edit freely.

## Session start
1. Read `_session-briefing.md`, then `_vault-map.md`. Open other notes only when the task needs them.

## General
- Check Stack/ before asking what tools I use.
- Evidence before assertions: open the file, page or data before describing it.
- Act on clear requests; flag gaps with `<!-- verify -->` instead of stopping to ask.
- Create files, don't just show content, when the result is meant to be kept.
- Be concise. Don't repeat what's already in the vault.

## Writing to the vault
- One canonical vault path (see CLAUDE.md). Never write to duplicates or conflict copies.
- Update the project note and index after work that changes state.
- Only file what I decided, never your own suggestions as my decisions.
- Never store passwords, keys, recovery codes or account numbers.

## Lessons (playbook)
Format: `- [YYYY-MM-DD] Trigger: <exact situation>. Rule: <what to do>. Why: <one line>.`
- [YYYY-MM-DD] Trigger: about to plan changes to something based on a note describing it. Rule: open the real thing first, then fix the note. Why: notes go stale.
