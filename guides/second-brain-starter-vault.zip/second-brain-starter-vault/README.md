# Second Brain Starter Vault

From the free guide at https://stuartsingleton.com/guides/second-brain-for-ai

1. Move this folder somewhere permanent and open it in Obsidian ("Open folder as vault").
2. Put the folder's full path into CLAUDE.md.
3. Fill in _session-briefing.md and Profile/about.md (or paste the AI playbook from the guide
   into Claude or ChatGPT and let it interview you and fill them in).
4. Connect the folder to Claude Code or the Claude desktop app so it can read and write here.
