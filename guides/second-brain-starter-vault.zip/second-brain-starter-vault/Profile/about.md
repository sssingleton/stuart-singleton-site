# About Me

- Name:
- Work / roles:
- What I'm good at:
- What I want help with most:
- Working style and preferences:
- Time zone:
