# Tools and Integrations

> What I use, so the AI checks here instead of asking. Never put passwords or keys here; note where they live instead.

| Tool | What I use it for | Notes |
|---|---|---|
| | | |
