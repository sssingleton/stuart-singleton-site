# How to use my vault

This folder is my second brain. Treat it as long-term memory.

Vault path: /REPLACE/WITH/THE/FULL/PATH/TO/THIS/FOLDER
(There is exactly one real copy of this vault. Never write anywhere else.)

## Every session
1. Read `_session-briefing.md` first, then `_vault-map.md`.
2. Open other notes only when the task needs them. Targeted reads, not the whole vault.
3. Before planning work on something real (code, a document, a page), open the real thing.
   If a note disagrees with it, the real thing wins. Fix the note.

## Writing back
- After work that changes a project, update its note in `Projects/` and its line in
  `Projects/_active-projects.md`.
- New notes use the templates in `Templates/`. Read the template file, don't recreate it from memory.
- Decisions: list `Decisions/` first, use the highest number plus one, add a row to
  `Decisions/_decision-log.md`. When a decision changes, write a new one and mark the old
  one `superseded`.
- Running topics go in `Threads/` with a line in `Threads/_open-threads.md`.
- Standing rules go in `Constraints/rules.md`. My shorthand goes in `Glossary/terms.md`.
- Unsure about a fact? Write it with `<!-- verify -->` instead of guessing or stopping to ask.
- Only file what I actually decided. Your suggestions are not my decisions.

## Never store
Passwords, API keys, recovery codes, account numbers, or other people's private details.
Note where a secret lives, never the secret.

## Status words
Projects: planning | in-progress | blocked | on-hold | shipped
Threads: active | resolved
Decisions: proposed | accepted | superseded
