# Decision Log

> Every real choice, one row each, so settled questions stay settled.
> To add one: list this folder, use the highest number plus one, copy Templates/decision.md,
> then add a row here. When a decision changes, write a new one and mark the old one superseded.

| # | Decision | Date | Status |
|---|---|---|---|
| 001 | [[001-example-decision\|Example: replace with your first real decision]] | YYYY-MM-DD | proposed |
