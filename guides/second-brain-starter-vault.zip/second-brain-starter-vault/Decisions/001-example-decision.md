# Decision 001: Example Decision

**Date**: YYYY-MM-DD
**Status**: `proposed`

## Context
What prompted this decision.

## Decision
What was decided.

## Alternatives Considered
- Alternative 1, and why not
- Alternative 2, and why not

## Consequences
- What this means going forward
